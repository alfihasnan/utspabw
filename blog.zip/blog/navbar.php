<?php
  if (isset($_POST['login'])) {
    if (login($_POST) > 0) {
      $user=$_POST['username'];
      $_SESSION['username']=$user;
      echo "<script>alert('Selamat Datang, $user');window.location.href='index.php'</script>";
    }else{
      echo "<script>alert('Username/Password Salah');window.location.href='index.php'</script>";
    }
  }
  if (isset($_POST['simpanblog'])) {
    if (simp_blog($_POST) > 0) {
      echo "<script>alert('Post Berhasil Ditambahkan');window.location.href='index.php'</script>";
    }else{
      echo "<script>alert('Gagal Menyimpan Post');window.location.href='index.php'</script>";
    }
  }
  if (isset($_POST['hapuspost'])) {
    if (hapus_blog($_POST) > 0) {
      echo "<script>alert('Post Berhasil Dihapus');window.location.href='index.php'</script>";
    }else{
      echo "<script>alert('Gagal Menghapus Post');window.location.href='index.php'</script>";
    }
  }
  if (isset($_POST['simpanuser'])) {
    if (simp_user($_POST) > 0) {
      echo "<script>alert('User Berhasil Ditambahkan');window.location.href='index.php'</script>";
    }else{
      echo "<script>alert('Gagal Menyimpan User');window.location.href='index.php'</script>";
    }
  }
  if (isset($_POST['resetuser'])) {
    if (reset_user($_POST) > 0) {
      echo "<script>alert('Password Berhasil Direset');window.location.href='index.php'</script>";
    }else{
      echo "<script>alert('Gagal Mereset Password');window.location.href='index.php'</script>";
    }
  }
  if (isset($_POST['hapususer'])) {
    if (hapus_user($_POST) > 0) {
      echo "<script>alert('User Berhasil Dihapus');window.location.href='index.php'</script>";
    }else{
      echo "<script>alert('Gagal Menghapus User');window.location.href='index.php'</script>";
    }
  }
?>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
  <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
  <!-- Custom styles for this template -->
  <link href="css/clean-blog.min.css" rel="stylesheet">

</head>

<body>
<!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand" href="index.php">Ramadhan Blog</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <?php if(!isset($_SESSION['username'])){ ?>
          <li class="nav-item">
            <a class="nav-link" href="#" data-toggle="modal" data-target="#loginModal">Log In</a>
          </li>
          <?php }else{ ?>
          <li class="nav-item">
            <a class="nav-link" href="#" data-toggle="modal" data-target="#blogModal">Kelola Blog</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" data-toggle="modal" data-target="#userModal">Kelola User</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">Log Out</a>
          </li>
          <?php } ?>
        </ul>
      </div>
    </div>
  </nav>

  <div class="modal fade bd-example-modal-xl" id="blogModal" tabindex="-1" role="dialog" aria-labelledby="blogModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="blogModalLabel">Kelola Blog</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form method="post">
              <label for="judul">Judul</label>
              <input type="text" name="judul" id="judul" class="form-control" placeholder="Judul" required>
              <label for="konten">Konten</label>
              <textarea class="form-control" name="konten" id="konten" placeholder="Isi konten blog disini"></textarea>
              <!--<input type="text" name="konten" id="konten" class="form-control" placeholder="Isi konten blog disini" required>-->
              <input type="hidden" name="penulis" value="<?php echo $_SESSION['username']; ?>">
              <input type="submit" name="simpanblog" class="btn btn-success my-2" value="Simpan">
            </form>
            <table class="table table-hover" id="tb_blog">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">No.</th>
                  <th scope="col">Judul</th>
                  <th scope="col">Penulis</th>
                  <th scope="col">Tanggal</th>
                  <th scope="col"></th>
                </tr>
              </thead>
              <tbody>
                <?php
                  $getpost=tampil_all_post();
                  $no=0;
                  while($tblog=mysqli_fetch_array($getpost)){
                    $no++;
                ?>
                <tr>
                  <td><?php echo $no; ?></td>
                  <td><?php echo $tblog[1]; ?></td>
                  <td><?php echo $tblog[2]; ?></td>
                  <td><?php echo $tblog[4]; ?></td>
                  <td><form method="post"><input type="hidden" name="id" value="<?php echo $tblog[0]; ?>">
                  <input type="submit" name="hapuspost" class="btn btn-danger btn-sm" value="Hapus"></form></td>
                </tr>
                <?php
                  }
                ?>
              </tbody>
            </table>
          </div>
          <!--
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
          -->
        </div>
      </div>
    </div>

    <div class="modal fade bd-example-modal-xl" id="userModal" tabindex="-1" role="dialog" aria-labelledby="userModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="userModalLabel">Kelola User</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form method="post">
              <label for="username">Username</label>
              <input type="text" name="username" id="username" class="form-control" placeholder="Username" required>
              <label for="password">Password</label>
              <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
              <input type="submit" name="simpanuser" class="btn btn-success my-2" value="Simpan">
            </form>
            <table class="table table-hover" id="tb_user">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">No.</th>
                  <th scope="col">Username</th>
                  <th scope="col">Password</th>
                  <th scope="col"></th>
                </tr>
              </thead>
              <tbody>
                <?php
                  $getuser=tampil_all_user();
                  $no=0;
                  while($tuser=mysqli_fetch_array($getuser)){
                    $no++;
                ?>
                <tr>
                  <td><?php echo $no; ?></td>
                  <td><?php echo $tuser[0]; ?></td>
                  <td><?php echo $tuser[1]; ?></td>
                  <td class="form-inline">
                  <form method="post"><input type="hidden" name="username" value="<?php echo $tuser[0]; ?>">
                  <input type="submit" name="resetuser" class="btn btn-primary btn-sm mr-3" value="Reset"></form>

                  <form method="post"><input type="hidden" name="username" value="<?php echo $tuser[0]; ?>">
                  <input type="submit" name="hapususer" class="btn btn-danger btn-sm" value="Hapus"></form></td>
                </tr>
                <?php
                  }
                ?>
              </tbody>
            </table>
          </div>
          <!--
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Save changes</button>
          </div>
          -->
        </div>
      </div>
    </div>

  <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="loginModalLabel">Login</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="post">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" class="form-control" placeholder="Username" required>
            <label for="password">Password</label>
            <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success" name="login">Login</button>
          </form>
        </div>
      </div>
    </div>

    

  </div>