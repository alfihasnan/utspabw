<?php
	$koneksi=mysqli_connect("localhost","root","","blog") or die(mysqli_error($koneksi));

	function tampil_all_post(){
		global $koneksi;
		$sql="SELECT * FROM post";
		$result = mysqli_query($koneksi,$sql);
		return $result;
	}
	function login($data){
		global $koneksi;
		$username=$data['username'];
		$password=$data['password'];
		$sql="SELECT * FROM user WHERE username='$username' AND password='$password'";
		mysqli_query($koneksi,$sql);
		return mysqli_affected_rows($koneksi);
	}
	function tampil_all_user(){
		global $koneksi;
		$sql="SELECT * FROM user";
		$result = mysqli_query($koneksi,$sql);
		return $result;
	}
	function simp_blog($data){
		global $koneksi;
		$judul=$data['judul'];
		$konten=$data['konten'];
		$penulis=$data['penulis'];
		$sql="INSERT INTO post (judul,username,konten,tanggal) VALUES ('$judul','$penulis','$konten',NOW())";
		mysqli_query($koneksi,$sql);
		return mysqli_affected_rows($koneksi);
	}
	function hapus_blog($data){
		global $koneksi;
		$id=$data['id'];
		$sql="DELETE FROM post WHERE id='$id'";
		mysqli_query($koneksi,$sql);
		return mysqli_affected_rows($koneksi);
	}
	function simp_user($data){
		global $koneksi;
		$username=$data['username'];
		$password=$data['password'];
		$sql="INSERT INTO user VALUES ('$username','$password')";
		mysqli_query($koneksi,$sql);
		return mysqli_affected_rows($koneksi);
	}
	function reset_user($data){
		global $koneksi;
		$username=$data['username'];
		$sql="UPDATE user SET password='123456' WHERE username='$username'";
		mysqli_query($koneksi,$sql);
		return mysqli_affected_rows($koneksi);
	}
	function hapus_user($data){
		global $koneksi;
		$username=$data['username'];
		$sql="DELETE FROM user WHERE username='$username'";
		mysqli_query($koneksi,$sql);
		return mysqli_affected_rows($koneksi);
	}
?>