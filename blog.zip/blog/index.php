<?php
	require 'function.php';
	session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Home - Ramadhan Blog</title>

  <?php require 'navbar.php'; ?>

  <!-- Page Header -->
  <header class="masthead" style="background-image: url('image/home-bg.jpg')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h1>Ramadhan Blog</h1>
            <span class="subheading">Berbagi Info Tentang Ramadhan</span>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
	  	<?php
	  		$getpost=tampil_all_post();
	  		$index=0;
	  		while ($tampil=mysqli_fetch_array($getpost)) {
	  			$index++;
	  	?>
        <div class="post-preview">
          <a href="#" data-toggle="modal" data-target="#postModal<?php echo $index; ?>">
            <h2 class="post-title">
              <?php echo $tampil[1]; ?>
            </h2>
            <!--<h3 class="post-subtitle">
              <?php //echo $tampil[3]; ?>
            </h3>-->
          </a>
          <p class="post-meta">Posted by
            <a href="#"><?php echo $tampil[2]; ?></a>
            on <?php echo $tampil[4]; ?></p>
        </div>
        <hr>
        <div class="modal fade bd-example-modal-xl" id="postModal<?php echo $index; ?>" tabindex="-1" role="dialog" aria-labelledby="postModalLabel" aria-hidden="true">
	      <div class="modal-dialog modal-xl" role="document">
	        <div class="modal-content">
	          <div class="modal-header">
	            <h5 class="modal-title" id="postModalLabel"><?php echo $tampil[1]; ?></h5>
	            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	              <span aria-hidden="true">&times;</span>
	            </button>
	          </div>
	          <div class="modal-body">
	            <?php echo $tampil[3]; ?>
	          </div>
	      	</div>
		  </div>
		</div>
        <?php
        	}
        ?>

        <!-- Pager -->
        <!--
        <div class="clearfix">
          <a class="btn btn-primary float-right" href="#">Older Posts &rarr;</a>
        </div>
    	-->
      </div>
    </div>
  </div>

  <hr>

  <?php require 'footer.php'; ?>

</body>

</html>
